package lt.codeacademy.dto;

public class BookingDto {

}
