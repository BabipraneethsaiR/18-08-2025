package lt.codeacademy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineMovieTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMovieTicketApplication.class, args);
	}

}
