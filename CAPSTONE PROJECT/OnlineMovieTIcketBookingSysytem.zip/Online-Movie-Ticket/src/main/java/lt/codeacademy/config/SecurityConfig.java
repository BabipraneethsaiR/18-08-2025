package lt.codeacademy.config;

public class SecurityConfig {

}
