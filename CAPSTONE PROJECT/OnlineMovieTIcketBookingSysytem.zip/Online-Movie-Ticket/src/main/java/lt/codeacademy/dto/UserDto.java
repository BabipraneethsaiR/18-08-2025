package lt.codeacademy.dto;

public class UserDto {

}
