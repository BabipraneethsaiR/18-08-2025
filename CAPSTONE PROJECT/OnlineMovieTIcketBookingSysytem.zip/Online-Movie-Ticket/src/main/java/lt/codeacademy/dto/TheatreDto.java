package lt.codeacademy.dto;

public class TheatreDto {

}
