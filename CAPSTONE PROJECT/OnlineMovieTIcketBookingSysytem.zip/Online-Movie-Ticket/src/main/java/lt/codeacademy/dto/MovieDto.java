package lt.codeacademy.dto;

public class MovieDto {

}
